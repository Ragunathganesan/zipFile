package steps_CommerceStore;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CheckoutPage extends Base {

	@And("Click the Shipping Method dropdown and select {string}")
	public void selectShippingMethod(String dd) {
		driver.findElement(By.xpath("//body")).sendKeys(Keys.PAGE_DOWN);
		WebElement shippingMethod = driver
				.findElement(By.xpath("//p[contains(text(),'Shipping method')]/following::select"));

		Select select = new Select(shippingMethod);
		select.selectByVisibleText(dd);

	}

	@When("Click Make payment")
	public void clickMakePayment() {
		driver.findElement(By.xpath("//body")).sendKeys(Keys.PAGE_DOWN);
		driver.findElement(By.xpath("//button[text()='Make payment']")).click();

	}

}
