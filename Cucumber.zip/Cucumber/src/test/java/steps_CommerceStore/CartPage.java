package steps_CommerceStore;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;

public class CartPage extends Base {

	@And("Click Checkout")
	public void clickCheckout() {
		 driver.findElement(By.xpath("//a[text()='Checkout']")).click();

	}
	
}
