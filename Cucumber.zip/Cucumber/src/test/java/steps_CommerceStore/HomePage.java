package steps_CommerceStore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class HomePage extends Base {

	@Given("Click Shop now")
	public void clickShopNow() {
		WebElement shopNow = driver.findElement(By.xpath("(//a[text()='Shop now'])[1]"));
		driver.executeScript("arguments[0].click();", shopNow);

	}

}
