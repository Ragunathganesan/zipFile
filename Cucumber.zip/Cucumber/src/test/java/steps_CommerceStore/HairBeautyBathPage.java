package steps_CommerceStore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.And;

public class HairBeautyBathPage extends Base {

	@And("Click Add to cart")
	public void clickAddToCart() {
		WebElement addToCart = driver.findElement(By.xpath("//span[text()='Add to cart']"));
		wait.until(ExpectedConditions.visibilityOf(addToCart));
		addToCart.click();

	}

	@And("Verify Cart Count")
	public void verifyCartCount() {
		WebElement cartCount = driver.findElement(By.xpath("//div[text()='1'][contains(@class,'cart-count')]"));
		wait.until(ExpectedConditions.visibilityOf(cartCount));

	}

	@And("Click Cart")
	public void clickCart() {
		driver.findElement(By.xpath("//div[@class='cart-animation']")).click();

	}

}
