package steps_CommerceStore;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class Base extends AbstractTestNGCucumberTests {

	public static RemoteWebDriver driver;
	public static WebDriverWait wait;

	//@Parameters({ "Browser", "URL" })
	@BeforeMethod
	public void startApp() {

//		if (browser.equalsIgnoreCase("chrome")) {
//			ChromeOptions option = new ChromeOptions();
//			option.addArguments("--disable-notifications");
//
//			driver = new ChromeDriver(option);
//		} else if (browser.equalsIgnoreCase("edge")) {
//
//			driver = new EdgeDriver();
//		}

		driver = new ChromeDriver();
		driver.get("https://commercejs-demo-store.netlify.app/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, Duration.ofSeconds(60));
	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();
	}

}
