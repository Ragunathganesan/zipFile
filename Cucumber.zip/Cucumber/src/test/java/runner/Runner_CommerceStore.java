package runner;

import io.cucumber.testng.CucumberOptions;
import steps_Leaftaps.Base;

@CucumberOptions(features = "src/test/java/features_commerceStore/Purchase_Product.feature", 
                 glue = "steps_CommerceStore", 
                 monochrome = true, 
                 publish = true)

public class Runner_CommerceStore extends Base {

}
