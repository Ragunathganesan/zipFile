package Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import Util.ReadExcel;
import io.cucumber.testng.AbstractTestNGCucumberTests;

import org.testng.annotations.Test;



public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{
    
	private static final ThreadLocal<RemoteWebDriver> rddriver = new ThreadLocal<RemoteWebDriver>();
	
	public RemoteWebDriver getDriver() {
		return rddriver.get();	}
	
	public void setDriver() {
		rddriver.set(new ChromeDriver());
	}
	
	public String filename;
	public static Properties prop;
	@Parameters({"language"})
	
	@BeforeMethod
	public void preCondition(String language) throws IOException {
		FileInputStream fis=new FileInputStream("./src/main/resources/"+language+".properties");
		
		prop=new Properties();
		
		prop.load(fis);
		setDriver();
		
		getDriver().get(prop.getProperty("url"));
		getDriver().manage().window().maximize();
		
	}
@AfterMethod
   public void postCondition() {
	getDriver().close();
	}

@DataProvider
public String[][] sendData() throws IOException {
	ReadExcel re = new ReadExcel();
	String[][] data = re.ReadExcel(filename);
	return data;
}

}
