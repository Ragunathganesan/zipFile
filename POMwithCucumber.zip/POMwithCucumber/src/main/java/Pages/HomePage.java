package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod{
	
	
	

	public LeadPage clickleads() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new LeadPage();
		}
}
