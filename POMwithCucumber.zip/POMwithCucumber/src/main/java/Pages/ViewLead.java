package Pages;


import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethod;

public class ViewLead extends ProjectSpecificMethod{

	
	
	
	public ViewLead verifycreateleadpage() {
		String title = getDriver().getTitle();
		System.out.println(title);
		return this;
	}
}
