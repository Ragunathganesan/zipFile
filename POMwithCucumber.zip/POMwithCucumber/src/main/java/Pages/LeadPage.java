package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethod;

public class LeadPage extends ProjectSpecificMethod {

	
	
	
		public CreateLead clickCreateLead() {
			getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLead();
		}
	}