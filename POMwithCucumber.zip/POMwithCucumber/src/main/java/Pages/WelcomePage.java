package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod{
	
	

	
	public HomePage Clickcrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new HomePage();
	}
    @Then("Welcome page is displayed")
	public WelcomePage verifypage() {
		String title = getDriver().getTitle();
		System.out.println(title);
		return this;
	}
}
