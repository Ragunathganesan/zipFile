package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{
	
	
	
	@Given("Enter the username as {string}")
	public LoginPage enterusername(String uname) {
		getDriver().findElement(By.id("username")).sendKeys(prop.getProperty("username"));
		return this;
		
	}
	@Given("Enter the password as {string}")

	public LoginPage enterPassword(String pwd) {
		getDriver().findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		return this;
	}
	@When("Click on the Login button")
	public WelcomePage clickLogin() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
		
	}

}
