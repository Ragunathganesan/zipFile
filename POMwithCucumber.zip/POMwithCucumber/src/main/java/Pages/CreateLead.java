package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import Base.ProjectSpecificMethod;

public class CreateLead extends ProjectSpecificMethod {
	
	
	
	
	public CreateLead enterComapnyName(String cname) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		return this;
		
	}
	
	public CreateLead enterFirstName(String fname) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;

	}
	
	public CreateLead enterLastName(String lname) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;

	}
	
	public ViewLead clickcreate() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewLead();

	
	

	}
	
}
