package testcases;

import Base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features= {"src/main/java/Features/Login.feature"},glue="Pages")
public class CucumberRunner extends ProjectSpecificMethod{

}
