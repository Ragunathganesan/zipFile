package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecificMethod;
import Pages.LoginPage;

public class TC001_Login extends ProjectSpecificMethod{
	
	
	@Test 
	public void runLogin(String uname,String pwd) {
      LoginPage login = new LoginPage();
//	login.enterusername();
//	login.enterPassword();
//	login.clickLogin();
	
		login.enterusername(uname).enterPassword(pwd).clickLogin().verifypage();
		
	}

}
