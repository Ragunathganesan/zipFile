package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.ProjectSpecificMethod;
import Pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethod {
    
	@BeforeTest
	public void setValues() {
		filename="Lead";
	}
	
	
	@Test(dataProvider = "sendData")
	  public void runcreate(String uname,String pwd,String cname, String fname, String lname) {
		
      new LoginPage().enterusername(uname).enterPassword(pwd).clickLogin().verifypage().Clickcrmsfa().
      clickleads().clickCreateLead().enterComapnyName(cname).enterFirstName(fname).enterLastName(lname).clickcreate()
      .verifycreateleadpage();
	  	
		  
	  }
	  
}
