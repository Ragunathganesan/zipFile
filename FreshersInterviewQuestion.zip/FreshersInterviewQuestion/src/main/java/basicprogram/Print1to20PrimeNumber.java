package basicprogram;

public class Print1to20PrimeNumber {
	public static void main(String[] args) {

		//Iterate the values from 1 to 20
		for (int i = 1; i <=20; i++) {
			//Initialize the count values as 0
			int count = 1;
			//if the number is prime it divisible by 1 and itself
			for (int j = 1; j <i; j++) {
				//if it is divisible by 0
				if(i%j==0) {
					//increse the count
					count++;
				}
			}
        //if the count is equal to 2 the given number is prime
			if(count==2) {
				System.out.println("This is prime number"+i);
			}
		}
	}
}																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																			