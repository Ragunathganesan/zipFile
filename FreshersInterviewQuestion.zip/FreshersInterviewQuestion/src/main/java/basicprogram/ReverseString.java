package basicprogram;

public class ReverseString {
public static void main(String[] args) {
	String name="Aravind";
	char[] charArray = name.toCharArray();
	for (int i = charArray.length-1;i>=0; i--) {
		System.out.println(charArray[i]);
	}
}
}
