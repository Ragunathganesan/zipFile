package basicprogram;

import java.util.Arrays;

public class PrintDuplicate {
public static void main(String[] args) {
	int[] num= {22,11,10,10,22};
	
    Arrays.sort(num);
	  for (int i =0;i<num.length;i++) {
		  for (int j = i+1; j < num.length; j++) {
			  if (num[i] == num[j]) {
				  
					System.out.println("Duplicate"+num[i]);
						 
						 }
		}
		
		 
		  
}
}
}
