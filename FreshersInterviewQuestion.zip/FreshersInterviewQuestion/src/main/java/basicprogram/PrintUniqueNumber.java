package basicprogram;

import java.util.LinkedHashSet;
import java.util.Set;

public class PrintUniqueNumber {
public static void main(String[] args) {
	int[] num= {1,2,3,4,5,6,1,2,3};
	Set<Integer> val=new LinkedHashSet<Integer>();
	for (int i = 0; i < num.length; i++) {
		val.add(num[i]);
	}
	System.out.println(val);
	
	//Another solution
	for (int i = 0; i < num.length; i++) {
		int count=1;
		for (int j = i+1; j < num.length; j++) {
			if(num[i]==num[j]) {
				num[j]=999;
			}
		}
		if(count>=1 && num[i]!=999) {
			System.out.println(num[i]);
		}
	}
}
}
