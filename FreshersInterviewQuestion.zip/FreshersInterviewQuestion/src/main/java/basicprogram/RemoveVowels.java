package basicprogram;

public class RemoveVowels {
public static void main(String[] args) {
	String text="testleaf";
	
	String replaceAll = text.replaceAll("[aeiou]", "");
	System.out.println(replaceAll);
}
}
