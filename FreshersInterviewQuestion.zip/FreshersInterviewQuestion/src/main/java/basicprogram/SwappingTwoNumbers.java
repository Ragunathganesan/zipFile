package basicprogram;

public class SwappingTwoNumbers {
public static void main(String[] args) {
	int a=35;
	int b=28;
	//declare the temp variable
	int temp;
	//Assign the a value to temp 
	temp=a;
	a=b;
	System.out.println(a);
	b=temp;
	System.out.println(b);
//Another way	
	int x = 10;
    int y = 5;
    x=x-y;
    y=x+y;

    System.out.println(x);
    System.out.println(y);
	
}
}
