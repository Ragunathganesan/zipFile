package basicprogram;

public class SumOfDigit {
public static void main(String[] args) {
	String text="12345";
	int parseInt = Integer.parseInt(text);
	System.out.println(parseInt);
	int sum=0;
	while(parseInt>0) {
	int remainder=parseInt%10;
	sum=sum+remainder;
	parseInt=parseInt/10;
	System.out.println(sum);
}
	
}
}
