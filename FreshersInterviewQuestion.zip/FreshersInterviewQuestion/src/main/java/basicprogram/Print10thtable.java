package basicprogram;

public class Print10thtable {
	public static void main(String[] args) {
		//Initialize the value to multiple by which value
		int a=10;
		//Irate the value from 1 to 10
		for (int i = 1; i <=10; i++) {
			//To multiple the iterating values and store into b
			int b=a*i;
			//Print the table
			System.out.println(i+"*"+a+"="+b);
		}
	}
}
