package extra;

public class TwoSum {
public static void main(String[] args) {
	int[] num= {1,3,4,5,6,8,9,2,5,3,8};
	int target=10;
	for (int i = 0; i < num.length; i++) {
		for (int j = i+1; j < num.length; j++) {
			if(num[i]+num[j]==target) {
				System.out.print(num[i]);
				System.out.println();
			}
		}
	}
}
}
