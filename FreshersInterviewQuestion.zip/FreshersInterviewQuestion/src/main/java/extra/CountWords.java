package extra;

public class CountWords {
public static void main(String[] args) {
	String word="Amazon developmenet center 12000 chennai";
	//String replaceAll = word.replaceAll("\\D", "");
	
	char[] charArray = word.toCharArray();
	for (int i = 0; i < charArray.length; i++) {
		if(Character.isDigit(charArray[i])) {
			System.out.print(charArray[i]);
		}
	}
	
	//System.out.println(replaceAll);
//	 word.toLowerCase();
//	String[] split = word.split(" ");
//	for (int i =split.length-1;i>=0; i--) {
//		System.out.println(split[i]);
//	}
}
}
