package zakapps;

public class SumOfDigit {
	public static void main(String[] args) {

		int input=556;
		//Initialize the sum values as 0
		int sum=0;
		//To iterate the loop until my condition is satisfied
		while(input>0) {
			//to find the remainder using %
			int remainder=input%10;
			//Store the values in  sum
			sum=sum+remainder;
			System.out.println(sum);
			//also num divide by 10 to move the next number
			input=input/10;
		}
		//Print the sum of digit for given input
		System.out.println(sum);
	}
}
