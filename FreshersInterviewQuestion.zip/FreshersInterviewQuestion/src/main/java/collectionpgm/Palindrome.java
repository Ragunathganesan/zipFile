package collectionpgm;

public class Palindrome {
public static void main(String[] args) {
	String str = "madama";
	String rev="";
	char[] charArray = str.toCharArray();
	for (int i = charArray.length-1;i>=0; i--) {
		rev=rev+charArray[i];
		System.out.println(rev);
	}
	if(rev.equals(str)) {
		System.out.println("The Given String is palindrome   "+rev);
	}else {
		System.out.println("The Given String is not  palindrome"+rev);
	}
}
}
