package collectionpgm;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class MissingElementUsingSet {
public static void main(String[] args) {
	int[] num= {1,4,7,9,2,5,3,6,7,2,3,4,5};
	
	Set<Integer> val=new TreeSet<Integer>();
	
	for (int i = 0; i < num.length; i++) {
		val.add(num[i]);
	}
	//print Uniques number
	System.out.println(val);
	
	List<Integer> missingElement=new ArrayList<Integer>(val);
	for (int i = 0; i < missingElement.size()-1; i++) {
		if(missingElement.get(i)+1!=missingElement.get(i+1)) {
			System.out.println(missingElement.get(i)+1);
		}
	}
	
	
	
}
}
