package todattest;

public class PrintAllCharacter2 {
public static void main(String[] args) {
	String text="testleaf123$@gmail.com";
	char[] charArray = text.toCharArray();
	int count=0;
	for (int i = 0; i < charArray.length; i++) {
		
		if(charArray[i]>='A'&&charArray[i]<='Z' ||charArray[i]>='a'&&charArray[i]<='z') {
			System.out.print(charArray[i]);
			
		}
		
		else if (charArray[i]>='0'&&charArray[i]<='9' ) {
			System.out.print(charArray[i]);
		
		}
		else if (charArray[i]>=33&&charArray[i]<=47 ||charArray[i]>=58&&charArray[i]<=64 ) {
			System.out.print(charArray[i]);
		}
	}
}
}
