package todattest;

public class PrintAllCharacter {
public static void main(String[] args) {
	String text="testleaf123$@gmail.com";
	char[] charArray = text.toCharArray();
	int count=0;
	for (int i = 0; i < charArray.length; i++) {
		
		if(charArray[i]>=65&&charArray[i]<=90 ||charArray[i]>=97&&charArray[i]<=122) {
			System.out.print(charArray[i]);
			
		}
		
		else if (charArray[i]>=48&&charArray[i]<=57 ) {
			System.out.print(charArray[i]);
		
		}
		else if (charArray[i]>=33&&charArray[i]<=47 ||charArray[i]>=58&&charArray[i]<=64 ) {
			System.out.print(charArray[i]);
		}
	}
}
}
