package todattest;

public class RemoveVowels {
public static void main(String[] args) {
	String text="Architecture";
	
	String replaceAll = text.replaceAll("[a,e,i,o,u,A,E,I,O,U]", "");
	System.out.println(replaceAll);
}
}
