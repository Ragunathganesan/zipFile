package todattest;

public class SumOfDigit2 {
public static void main(String[] args) {
	int[] num= {1,2,3,4,5};
	int j=0;
	for (int i = 0; i <= num.length-1; i++) {
		j=j+num[i];
		System.out.println(j);
	}
}
}
