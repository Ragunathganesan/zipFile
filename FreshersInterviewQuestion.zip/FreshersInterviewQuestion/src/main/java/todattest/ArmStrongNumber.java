package todattest;

import java.util.Scanner;

import org.apache.commons.collections4.bag.SynchronizedSortedBag;

public class ArmStrongNumber {
public static void main(String[] args) {
	Scanner scan=new Scanner(System.in);
	int nextInt = scan.nextInt();
	//String nextLine = scan.nextLine();
	int sum=0;
	String string = Integer.toString(nextInt);
	int length = string.length();
	int temp=nextInt;
	while (nextInt>0) {
		int rem=nextInt%10;
		sum+=Math.pow(rem, length);
		System.out.println(sum);
		temp=temp/10;
	}
	if(temp==nextInt) {
		System.out.println("Armstrong Number");
	}else {
		System.out.println("not Armstrong Number");
	}
}
}
