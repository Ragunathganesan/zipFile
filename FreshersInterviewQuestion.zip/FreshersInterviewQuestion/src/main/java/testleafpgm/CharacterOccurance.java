package testleafpgm;

public class CharacterOccurance {
public static void main(String[] args) {
	String text="welcome to chennai";

	char[] charArray = text.toCharArray();
	int count =0;
	for (int i = 0; i < charArray.length; i++) {
		if(charArray[i]=='e') {
			count++;
		}
	}
	System.out.println("e occurances is "+count);
}
}
