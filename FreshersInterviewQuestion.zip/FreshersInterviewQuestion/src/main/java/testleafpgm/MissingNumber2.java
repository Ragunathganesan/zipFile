package testleafpgm;

public class MissingNumber2 {
public static void main(String[] args) {
	
	int[] num= {1,2,3,4,5,7,8,9};
	
	int sum1=0;
	for (int i = 1; i <=9; i++) {
		sum1=sum1+i;
	}
	System.out.println(sum1);
	
	int sum2=0;
	for (int i = 0; i < num.length; i++) {
		sum2=sum2+num[i];
	}
	System.out.println(sum2);
	
	int sum3=sum1-sum2;
	System.out.println(sum3);
}
}
