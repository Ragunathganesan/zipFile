package testleafpgm;

public class PrintDuplicate {
public static void main(String[] args) {
	int[] arr = {14,12,13,11,15,14,18,16,17,19,18,17,20};
	//Iterate the array to length
	for (int i = 0; i < arr.length; i++) {
		// iterate from i to the length of the array 
		//by adding 1 to it (inner loop starts here)
		for (int j = i+1; j < arr.length; j++) {
			//compare both Array ,if it is match
			if(arr[i]==arr[j]) {
				//Print the Duplicate Number
				System.out.println(arr[i]);
			}
		}
	}
}
}
