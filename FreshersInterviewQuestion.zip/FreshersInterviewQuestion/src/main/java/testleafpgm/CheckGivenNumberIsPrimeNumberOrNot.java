package testleafpgm;

public class CheckGivenNumberIsPrimeNumberOrNot {
	
	public void method1(int number) {
		//check the given number is prime or not
		//int number=13;
		int count=0;
		
		for (int i = 1; i <= number; i++) {
			
			if(number%i==0) {
				count++;
			}
		}
		if(count==2) {
			System.out.println("The Given Number is Prime");
		}else {
			System.out.println("The Given Number is not  Prime");
		}
	}
	public void method2(int number) {
		//check the given number is prime or not using boolean
		
		boolean flag=false;
		
		for (int i = 2; i <= number-1; i++) {
			
			if(number%i==0) {
				flag=true;
			}
		}
		if(!flag) {
			System.out.println("The Given Number is Prime");
		}else {
			System.out.println("The Given Number is not  Prime");
		}
	}
	public static void main(String[] args) {
		CheckGivenNumberIsPrimeNumberOrNot number=new CheckGivenNumberIsPrimeNumberOrNot();
		number.method1(13);
		number.method2(17);
		
	}

}
