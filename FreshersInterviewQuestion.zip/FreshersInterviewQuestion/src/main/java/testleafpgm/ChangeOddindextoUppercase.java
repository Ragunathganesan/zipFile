package testleafpgm;

import java.util.Iterator;

public class ChangeOddindextoUppercase {
public static void main(String[] args) {
	//input String text="changeme";
	//output cHaNgEmE
	String text="changeme";
	
	char[] charArray = text.toCharArray();
	for (int i = 0; i < charArray.length; i++) {
		if(i%2 !=0) {
			char upperCase = Character.toUpperCase(charArray[i]);
			System.out.print(upperCase);
		}else {
			System.out.print(charArray[i]);
		}
	}
}
}
