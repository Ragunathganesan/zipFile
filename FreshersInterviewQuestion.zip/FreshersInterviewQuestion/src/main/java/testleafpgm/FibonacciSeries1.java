package testleafpgm;

public class FibonacciSeries1 {

	public static void main(String[] args) {
		
		int length=8;
		int firstNumber=0;
		int secondNumber=1;
		int sum=0;
		for (int i =1 ;i<=length;i++) {
			
			//0 +1   1
			//1+1  2
			//2+1 3
			//3+2   5
			//5+3    8
			
			sum=firstNumber+secondNumber;
			System.out.println(sum);
			firstNumber=secondNumber;
			secondNumber=sum;
		}
		// TODO Auto-generated method stub

	}

}