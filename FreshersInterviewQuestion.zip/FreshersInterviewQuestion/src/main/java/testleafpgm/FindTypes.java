package testleafpgm;

public class FindTypes {
public static void main(String[] args) {
	//here is input
			String test = "$$ Welcome to 2nd Class of Automation $$ ";
			// Here is what the count you need to find
					int  letter = 0, space = 0, num = 0, specialChar = 0;
					
					char[] ch = test.toCharArray();
	                 for (int i = 0; i < ch.length; i++) {
						if(Character.isLetter(ch[i])==true) 
				
							letter++;
					        else if(Character.isDigit(ch[i])==true) 	
							   num++;
						    else if(Character.isSpaceChar(ch[i])==true) 
						   
						      space++;	
					    else
				
					    specialChar++;
					
					}	
	              // Print the count here
	 				System.out.println("letter: " + letter);
	 				System.out.println("space: " + space);
	 				System.out.println("number: " + num);
	 				System.out.println("specialCharacter: " + specialChar);


}
}
