package testleafpgm;

public class RerverseEvenWords {
public static void main(String[] args) {
	String text = "I am a software tester";
	             // I ma a erawtfos tester 
	            //I am a software retset
	String[] split = text.split(" ");
	for (int i = 0; i < split.length; i++) {
		if(i%2!=0) {
			char[] charArray = split[i].toCharArray();
			for (int j = charArray.length-1; j >=0 ; j--) {			
				System.out.print(charArray[j]);
		}
	}
	else{
		System.out.print(" ");
		System.out.print(split[i]+" ");
}
}
}
}
