package testleafpgm;

public class MissingNumber {
public static void main(String[] args) {
	int[] num= {1,2,3,4,5,7,8,9};
	//int[] num= {8,10,12,13,15};
//	for (int i = 0; i < num.length-1; i++) {
//		if(num[i]+1!=(num[i+1])) {
//			System.out.println(num[i]+1);
//		}
//	}
	for (int i = 0; i < num.length; i++) {
		for (int j = i+1; j < num.length;) {
			if(num[i]-num[j]==1) {
				break;
			}else {
			System.out.println(num[i]+num[j]/2);
			}
		}
	}
	
	
	
	
	
	
	
	
	
}
}
