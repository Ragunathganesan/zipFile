package testleafpgm;

import java.util.AbstractList;

public class RemoveDuplicates {
public static void main(String[] args) {
	 String text1 = "We learn java basics as part of java sessions in java week1";
		int count = 0;
		String temp = "";
		
		String[] wordsArr = text1.split(" ");
		System.out.println(wordsArr);
		
		
		for (int i = 0; i < wordsArr.length; i++) {
			for (int j = i+1; j < wordsArr.length ; j++) {
				if (wordsArr[i].equals(wordsArr[j])) {
					temp = wordsArr[i];
					count += 1;
				}
			}
		}

		if (count >=1) {
			System.out.println(text1.replace(temp, ""));
		}

	  
	 }
	    

}
