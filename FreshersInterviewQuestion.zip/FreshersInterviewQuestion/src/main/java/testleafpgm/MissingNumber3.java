package testleafpgm;

import java.util.Arrays;

public class MissingNumber3 {
public static void main(String[] args) {
	
	int[] num= {1,2,3,4,6,7,5,9};
	Arrays.sort(num);
	for (int i = 0; i < num.length; i++) {
		int j=i+1;
		if(j!=num[i]) {
			System.out.println(j);
			//break;
		}
	
	
	}
}
}
