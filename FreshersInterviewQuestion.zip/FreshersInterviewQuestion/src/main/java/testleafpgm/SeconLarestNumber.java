package testleafpgm;

import java.util.Arrays;

 public abstract class SeconLarestNumber {
	 protected abstract void  me();
	 
public static void main(String[] args) {
	int num[]= {99,10,20,60,70};
	Arrays.sort(num);
	int length = num.length;
	System.out.println(num[4]);
}
}
