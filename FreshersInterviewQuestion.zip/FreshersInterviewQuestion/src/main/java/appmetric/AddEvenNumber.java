package appmetric;

public class AddEvenNumber {
	public static void main(String[] args) {
		//Declare a int Array
		int[] num= {1,2,3,4,5,6,7,8};
		//Initialize the sum value as 0
		int sum=0;
		//Iterate the values 0 to ArrayLength
		for (int i = 0; i < num.length; i++) {
			//To Add Only the even Number 
			if(num[i]%2==0) {
				//if it is even number to add the sum
				sum=sum+num[i];
				//Finally print the sum
				System.out.println(sum);
			}
		}
	}
}
