package appmetric;

import java.util.LinkedHashMap;
import java.util.Map;

public class PrintUniqueValue {
public static void main(String[] args) {
	int[] num= {1,1,4,5,1,2,2};
	// 1 occurance is 3
	//4 occurance is 1
	//5 occurance is 1
	//2 occurance is 2
	
	

	Map<Integer, Integer> val=new LinkedHashMap<Integer, Integer>();
	for (int i = 0; i < num.length; i++) {
		//if the value is  existing value add+1
		if(val.containsKey(num[i])) {
			Integer integer = val.get(num[i]);
			int newValue=integer+1;
			val.put(num[i], newValue);
			
		}else {
			//if not in existing value,add 
			val.put(num[i], 1);
		}
		
	}
	System.out.println(val);
}
}
