package appmetric;

public class PrintSmallestValueinStringArray {
public static void main(String[] args) {
	String[] text= {"ap","banana","apple","jack"};
	int charLength = 0;
	int maxValue = Integer.MAX_VALUE;
	String minCharValue = "";
			 
	for (int i = 0; i < text.length; i++) {
		
		charLength = text[i].length();
		if(maxValue>charLength) {
			maxValue=charLength;
			minCharValue = text[i];
		}
	}
	System.out.println(maxValue);
	System.out.println(minCharValue);
}
}
