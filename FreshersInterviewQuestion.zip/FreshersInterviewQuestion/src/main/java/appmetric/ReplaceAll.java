package appmetric;

public class ReplaceAll {
public static void main(String[] args) {
	
	String text="2363hfdkjfdwsdbfJABBSAGYYG";
	
	String val = text.replaceAll("[^a-z A-Z]", "");
	System.out.println(val);
}
}
