package appmetric;


import java.text.SimpleDateFormat;
import java.util.Date;

public class Cal {
public static void main(String[] args) {
	//To get the current date 
	Date date=new Date();
	System.out.println(date);
	//Set the the format
	SimpleDateFormat format=new SimpleDateFormat("dd-MM-yyyy");
	System.out.println(format.format(date));
}
}
