package appmetric;

import java.util.Scanner;

public class LeafYear {
public static void main(String[] args) {
	int year=2024;
	
	if(year%4==0 || year%100==0 || year%400==0) {
		System.out.println("Leaf Year1");
	}else if (year%100==0) {
		System.out.println("Leaf Year2");
	}else if (year%400==0) {
		System.out.println("Leaf Year3");
	}
	else {
		System.out.println("not Leaf Year");
	}
}
}
