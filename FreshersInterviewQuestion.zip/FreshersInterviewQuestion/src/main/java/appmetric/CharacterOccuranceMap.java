package appmetric;

import java.util.LinkedHashMap;
import java.util.Map;

public class CharacterOccuranceMap {
public static void main(String[] args) {
	String text="pradeepkumar";
	char[] charArray = text.toCharArray();
	
	Map<Character, Integer> val=new LinkedHashMap<Character, Integer>();
	
	for (int i = 0; i < charArray.length; i++) {
		
		if(val.containsKey(charArray[i])) {
			Integer integer = val.get(charArray[i]);
		int newValue=	integer+1;
		val.put(charArray[i], newValue);
		}else {
			val.put(charArray[i], 1);
		}
		
	}
	System.out.println(val);
	
}
}
