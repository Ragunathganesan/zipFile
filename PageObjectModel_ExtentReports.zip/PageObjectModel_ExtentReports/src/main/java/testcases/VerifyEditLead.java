package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.Base;
import pages.LoginPage;

public class VerifyEditLead extends Base{
	
	@BeforeTest
	public void setValues() {
		
		excelFileName="Login";
		sheetName="Sheet4";
		
		}

	@Test(dataProvider="sendData")
	public void EditLead(String uName,String pwd,String cmpnyName,String fName,
			             String lName,String desc,String email,String phNo,
			             String impNote) {
		
		LoginPage lp=new LoginPage(driver);
		lp.enterUsername(uName)
		.enterPassword(pwd)
		.clickLoginButton()
		.verifyHomePage()
		.clickCRMSFALink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(cmpnyName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.enterDescription(desc)
		.enterEmail(email)
		.enterPhoneNo(phNo)
		.clickCreate()
		.EditLead()
		.ClearDesc()
		.ImportantNote(impNote)
		.submit();

}
}
