package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.Base;
import pages.LoginPage;

public class VerifyLogin extends Base {
	
	@BeforeTest
	public void setValues() {
		
		excelFileName="Login";
		sheetName="Sheet1";
		testName="Login validation";
		testDesc="Login with valid credentials";
		testAuthor="Kavi";
		testCategory="regression";
	}
	
	@Test(dataProvider="sendData")
	public void runLogin(String uName,String pwd) throws IOException {
		
	   LoginPage lp = new LoginPage(driver);
	   lp.enterUsername(uName)
	   .enterPassword(pwd)
	   .clickLoginButton()
	   .verifyHomePage()
	   .clickCRMSFALink();
				
	}

}
