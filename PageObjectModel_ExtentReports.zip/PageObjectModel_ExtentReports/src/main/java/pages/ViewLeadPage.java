package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class ViewLeadPage extends Base{
	
	public static String id;
	
	public ViewLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
public ViewLeadPage verifyCreatedLead() {
		
		String fname = driver.findElement(By.xpath("//span[@id='viewLead_firstName_sp']")).getText();
		if(fname.equals(fname)) {
			
			System.out.println("Lead created succcessfully");
		}
		else {
			System.out.println("Lead not created successfully");
		}
		
     return this;
	}
public ViewLeadPage getLeadId() {
	
	String leadid = driver.findElement(By.id("viewLead_companyName_sp")).getText();
	int startposition=leadid.indexOf("(");
	int endposition=leadid.indexOf(")");
	String id=leadid.substring(startposition,endposition);
	System.out.println("Lead id:"+id);
	return this;
}

public EditLeadPage EditLead() {
	driver.findElement(By.linkText("Edit")).click();
	return new EditLeadPage(driver);

}

public DuplicateLeadPage DuplicateLead() {
	
	driver.findElement(By.linkText("Duplicate Lead")).click();
	return new DuplicateLeadPage(driver);

}

public MyLeadsPage DeleteLead() {
	
	driver.findElement(By.xpath("//a[text()='Delete']")).click();
	return new MyLeadsPage(driver);

}

}
