package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class LoginPage extends Base{
	
	public LoginPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public LoginPage enterUsername(String uName) throws IOException {

		   try {
			driver.findElement(By.id("username")).sendKeys(uName);
			reportStep("Valid user name","pass");
		} catch (Exception e) {
			
			reportStep("Invalid user name","pass");
		}   
		   return this;

		}
		public LoginPage enterPassword(String pwd) throws IOException {
			try {
				driver.findElement(By.id("password")).sendKeys(pwd);
				reportStep("Valid password","pass");
			} catch (Exception e) {
				
				reportStep("Invalid password","fail");
			}
			return this;

		}
		public WelcomePage clickLoginButton() throws IOException {
			
			try {
				driver.findElement(By.className("decorativeSubmit")).click();
				reportStep("Login clicked successfully","pass");
			} catch (Exception e) {
				reportStep("Login not clicked successfully","fail");
				
			}
			return new WelcomePage(driver);
			
		}
		

}
