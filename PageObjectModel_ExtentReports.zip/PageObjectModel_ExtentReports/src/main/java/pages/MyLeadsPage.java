package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class MyLeadsPage extends Base {
	
	public MyLeadsPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage clickCreateLeadLink() {
		
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage(driver);

	}

	public FindLeads clickFindLeads() {
		
		driver.findElement(By.xpath("//a[text()='Find Leads']")).click();
		return new FindLeads(driver);

	}
}
