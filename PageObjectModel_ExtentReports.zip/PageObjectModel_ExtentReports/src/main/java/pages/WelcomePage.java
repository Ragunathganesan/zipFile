package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class WelcomePage extends Base {
	
	public WelcomePage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public WelcomePage verifyHomePage() {
		String title = driver.getTitle();
		if (title.contains("Leaftaps")) {
			System.out.println("Login Successfull");
		}
		else {
			System.out.println("Login not successfull");
		}
		return this;

	}
	public MyHomePage clickCRMSFALink() {
		
		driver.findElement(By.partialLinkText("SFA")).click();
		return new MyHomePage(driver);

	}

}
