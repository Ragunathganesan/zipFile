package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class CreateLeadPage extends Base{
	
	public CreateLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage enterCompanyName(String cmpnyName) {
		
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cmpnyName);
		return this;
	}
	
    public CreateLeadPage enterFirstName(String fName) {
		
    	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
	}
  
    public CreateLeadPage enterLastName(String lName) {
		
    	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	}
    
    public CreateLeadPage enterDescription(String desc) {
		
    	driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);
		return this;
	}
    
    public CreateLeadPage enterEmail(String email) {
		
    	driver.findElement(By.id("createLeadForm_primaryEmail")).sendKeys(email);
		return this;
	}
    
    public CreateLeadPage enterPhoneNo(String phNo) {
		
    	driver.findElement(By.xpath("//input[contains(@id,'primaryPhoneNumber')]")).sendKeys(phNo);
		return this;
	}
	
    public ViewLeadPage clickCreate() {
		
    	driver.findElement(By.name("submitButton")).click();
    	return new ViewLeadPage(driver);

	}

}
