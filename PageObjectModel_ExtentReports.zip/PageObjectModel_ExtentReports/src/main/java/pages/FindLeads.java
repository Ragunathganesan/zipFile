package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class FindLeads extends Base{
	
	public FindLeads(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public FindLeads clickPhonetab() {
		
		driver.findElement(By.xpath("(//a[@class='x-tab-right'])[2]")).click();
	    return this;

	}
	
	public FindLeads enterPhoneNo() {
		
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys("900");
		return this;

	}
	
	public FindLeads clickFindLeads() throws InterruptedException {
		
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;

	}
	
	public ViewLeadPage clickResultingLeadId() {
		
		driver.findElement(By.xpath("(//a[@class='linktext'])[4]")).click();
		return new ViewLeadPage(driver);

	}
	
	public FindLeads enterLeadIdInNameTab() {
		
		driver.findElement(By.xpath("//input[@name='id']")).sendKeys(id);
		return this;

	}
	
	public FindLeads confirmLeadDeleted() {
		String msg=driver.findElement(By.xpath("//div[@class='x-paging-info']")).getText();
	    System.out.println("Message:"+msg);
	    return this;

	}

}
