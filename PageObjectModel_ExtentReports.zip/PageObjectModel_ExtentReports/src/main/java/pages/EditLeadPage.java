package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class EditLeadPage extends Base {
	
	public EditLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}
	
	public EditLeadPage ClearDesc() {
		
		driver.findElement(By.id("updateLeadForm_description")).clear();
		return this;

	}
	public EditLeadPage ImportantNote(String impNote) {
		
		driver.findElement(By.id("updateLeadForm_importantNote")).sendKeys(impNote);
		return this;
	}
	
	public ViewLeadPage submit() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadPage(driver);

	}

}
