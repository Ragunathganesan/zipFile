package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.Base;

public class DuplicateLeadPage extends Base{
	
	public DuplicateLeadPage(RemoteWebDriver driver) {
		this.driver=driver;
	}

	
	public DuplicateLeadPage companyName(String dupCmpnyName) {
		
		driver.findElement(By.id("createLeadForm_companyName")).clear();
	    driver.findElement(By.id("createLeadForm_companyName")).sendKeys(dupCmpnyName);
	    return this;

	}
    public DuplicateLeadPage firstName(String dupFname) {
		
    	driver.findElement(By.id("createLeadForm_firstName")).clear();
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(dupFname);
		return this;

	}
    
    public ViewLeadPage CreateLead() {
		
    	driver.findElement(By.linkText("Create Lead")).click();
    	System.out.println("Title :"+driver.getTitle());
    	return new ViewLeadPage(driver);

	}
}
