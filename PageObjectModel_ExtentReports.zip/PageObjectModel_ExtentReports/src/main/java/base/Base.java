package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadExcel;

public class Base {
	
	public  RemoteWebDriver driver;
	public static String id;
	public String excelFileName,sheetName;
	public static ExtentReports extent;
	public static ExtentTest test;
	public String testName,testDesc,testAuthor,testCategory;
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/results.html");
		reporter.setAppendExisting(true);
	    extent=new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testcasedetails() {
	    test=extent.createTest(testName,testDesc);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	
	public int takesnap() throws IOException {
		int ranNum = (int) Math.random();
		File src = driver.getScreenshotAs(OutputType.FILE);
		File dest=new File("./snaps/img"+ranNum+".png");
		FileUtils.copyFile(src,dest);
		return ranNum;

	}
	
	public void reportStep(String msg,String status) throws IOException {
		
		if(status.equalsIgnoreCase("pass")) {
			
			test.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takesnap()+".png").build());
		}
		else if(status.equalsIgnoreCase("fail")) {
			
			test.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takesnap()+".png").build());
		}

	}
	    
	    //@Parameters("browser")
		@BeforeMethod
		public void preCondition() {
			
			driver=new ChromeDriver();
	    	
//	    	if(browser.equalsIgnoreCase("chrome")) {
//	    		
//	    		driver=new ChromeDriver();
//	    	}
//	    	
//	    	else if(browser.equalsIgnoreCase("edge")) {
//	    		
//	    		driver=new EdgeDriver();
//	    		
//	    	}

			driver.get("http://leaftaps.com/opentaps/control/login");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		}

	    @AfterMethod
		public void postCondition() {
			driver.close();
		}
	    
	    @DataProvider(indices=1)
		public String[][] sendData() throws IOException {
			return ReadExcel.readExcelData(excelFileName,sheetName);

}
	    @AfterSuite
	    public void stopReport() {
			extent.flush();

		}
}
