package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Leaftaps_Steps extends BaseClass{
	
//	public ChromeDriver driver;
//	
//	@Given("Open the Chrome browser")
//	public void openbrowser() {
//		driver=new ChromeDriver();
//
//	}
//	
//	@And("Load the url")
//    public void loadurl() {
//    	driver.get("http://leaftaps.com/opentaps/control/login");
//    	driver.manage().window().maximize();
//
//	}
	
//	@Given("Enter the username as {string}")
//    public void usrname(String usrname) {
//    	driver.findElement(By.id("username")).sendKeys(usrname);
//
//	}
//    
//	@And("Enter the password as {string}")
//    public void pwd(String pwd) {
//    	driver.findElement(By.id("password")).sendKeys(pwd);
//
//	}
//    
//	@When("click on the login button")
//    public void clicklogin() {
//    	driver.findElement(By.className("decorativeSubmit")).click();
//
//	}
	
	@Then("Homepage should be displayed")
    public void verifyHomepage() {
		String title = driver.getTitle();
		System.out.println("Title:"+title);

	}
	
	@Given("click on the crmsfa link")
    public void clickcrmsfa() {
    	driver.findElement(By.partialLinkText("SFA")).click();

	}
	
	@And("click Leads button")
    public void clickLeads() {
    	driver.findElement(By.linkText("Leads")).click();

	}
	
	@And("click Create Lead")
    public void clickcreatelead() {
    	driver.findElement(By.linkText("Create Lead")).click();

	}
	
	@Given("Enter the companyname as (.*)$")
    public void companyname(String cmpnyname) {
    	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cmpnyname);

	}
	
	@And("Enter the firstname as (.*)$")
    public void firstname(String fname) {
    	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);

	}
	
	@And("Enter the lastname as (.*)$")
    public void lastname(String lname) {
    	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);

	}
	
	@And("Enter the description as (.*)$")
    public void description(String desc) {
    	driver.findElement(By.id("createLeadForm_description")).sendKeys(desc);

	}
	
	@And("Enter the phonenumber as (.*)$")
    public void phoneno(String phno) {
    	driver.findElement(By.xpath("//input[contains(@id,'primaryPhoneNumber')]")).sendKeys(phno);

	}
	
	@When("click on CreateLead button")
    public void submitcreatelead() {
    	driver.findElement(By.name("submitButton")).click();
    }
	
	@Then("ViewLeadPage should be displayed as (.*)$")
    public void viewleadpage(String cmpnyname) {
    	String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cmpnyname)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}

	}
}	



