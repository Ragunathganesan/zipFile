package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions extends BaseClass{
//	public ChromeDriver driver;
//	
//	@Given("Open the Chrome browser")
//	public void openbrowser() {
//		
//		 driver=new ChromeDriver();
//			}
//    @And("Load the url")
//	public void loadurl() {
//		
//		driver.get("http://leaftaps.com/opentaps/control/main");
//		driver.manage().window().maximize();
//		
//	}
	
    @Given("Enter the username as {string}")
	public void username(String uName) {
		
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(uName);
	}
	
    @And("Enter the password as {string}")
	public void pwd(String pwd) {
		
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(pwd);

	}
	
    @When("click on the login button")
	public void login() {
		
		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();

	}
	
//  @Then("Homepage should be displayed")
//	public void verifyhomepg() {
//		String confrmhomepg = driver.getTitle();
//		if (confrmhomepg.contains("Leaftaps")) {
////			
//			System.out.println("Successful Login");
//		}
////		
//		else {
////			
//			System.out.println("No Successful Login");
//		}
//    }
//	 @But("Errormsg should be displayed")	
//	 public void verifyError() {
//		  
//		String errmsg = driver.findElement(By.id("errorDiv")).getText();
//		if (errmsg.contains("Errors")) {
//			
//			System.out.println("Error msg verified");
//		}
  }



