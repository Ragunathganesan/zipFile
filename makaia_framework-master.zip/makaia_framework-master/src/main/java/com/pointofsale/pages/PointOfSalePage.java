package com.pointofsale.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class PointOfSalePage extends ProjectSpecificMethods {

	public CustomersPage clickCustomerTap() {
		click(locateElement(Locators.XPATH,"//h3[text()='Customers']"));
		reportStep("Customer tap clicked  successfully", "pass");
		return new CustomersPage();
	}
	public VendorsPage clickVendorsTap() {
		click(locateElement(Locators.XPATH,"//h3[text()='Vendors']"));
		reportStep("Vendor tap clicked  successfully", "pass");
	    return new VendorsPage();
	}
	public ProductPage clickProductTap() {
		click(locateElement(Locators.XPATH,"//h3[text()='Products']"));
		reportStep("Product tap clicked  successfully", "pass");
	    return new ProductPage();
	}
}
