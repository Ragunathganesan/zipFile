package com.pointofsale.pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class CustomersPage extends ProjectSpecificMethods {

	public NewCustomersPage clickCreateNewButton() {
		click(locateElement(Locators.XPATH,"//span[text()='Create New']"));
		reportStep("Create new Button clicked  successfully", "pass");
		return new NewCustomersPage();
	}
	public CustomersPage enterId(String id) {
		clearAndType(locateElement(Locators.XPATH, "//input[@placeholder='Enter ID']"), id,Keys.ENTER);
		reportStep(id+" id entered  successfully", "pass");
		return this;
	}
	public CustomersPage verifyCustomer(String customerId) {
		verifyExactText(locateElement(Locators.XPATH, "//table[contains(@class,'MuiTable-root')]//td[1]"), customerId);
		reportStep(customerId+" CustomerId verified  successfully", "pass");
		return this;
	}
	public EditCustomerPage clickEditIcon() {
		click(locateElement(Locators.XPATH,"//table[contains(@class,'MuiTable-root')]//td[1]/following::*[local-name()='svg']"));
		reportStep("Edit icon clicked  successfully", "pass");
		return new EditCustomerPage();
	}
	public CustomersPage verifyCustomerNameChanged(String customerNameChanged) {
		verifyExactText(locateElement(Locators.XPATH, "//table[contains(@class,'MuiTable-root')]//td[2]"), customerNameChanged);
		reportStep(customerNameChanged+" Customer name has changed successfully", "pass");
		return this;
	}
	public CustomersPage clickDeleteIcon() {
		click(locateElement(Locators.XPATH,"(//table[contains(@class,'MuiTable-root')]//td[1]/following::*[local-name()='svg'])[2]"));
		reportStep("Delete icon clicked  successfully", "pass");
		return this;
	}
	public CustomersPage confirmDeletePopup(String deletePopup) {
		verifyExactText(locateElement(Locators.ID, "alert-dialog-description"), deletePopup);
		reportStep(deletePopup+" Delete popup was displayed  successfully", "pass");
		return this;
	}
	public CustomersPage clickOKButton() {
		click(locateElement(Locators.XPATH,"//span[text()='Ok']"));
		reportStep("Ok button clicked successfully", "pass");
	    return this;
	}
	public CustomersPage verifyDeletePopUp(String verifyDeletePopup) {
		verifyExactText(locateElement(Locators.XPATH,"//div[text()='Message']/following-sibling::span"),verifyDeletePopup);
		reportStep(verifyDeletePopup+" Customer deleted popup displayed  successfully", "pass");
		return this;
	}
	
	public CustomersPage enterDeleteId(String deleteId) {
		Actions builder=new Actions(getDriver());
		builder.click(locateElement(Locators.XPATH, "//input[@placeholder='Enter ID']"))
		.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
		
		pause(2000);
		clearAndType(locateElement(Locators.XPATH, "//input[@placeholder='Enter ID']"), deleteId,Keys.ENTER);
		reportStep(deleteId+" id entered  successfully", "pass");
		return this;
	}
	public CustomersPage verifyCutomerDeleted() {
		//verifyDisplayed(locateElements(Locators.XPATH,"(//table[contains(@class,'MuiTable-root')]//td)[1]"));
		List<WebElement> locateElements = locateElements(Locators.XPATH, "//table[contains(@class,'MuiTable-root')]//td");
		int size = locateElements.size();
		if(size==0) {
			System.out.println("Customer deleted successfully");
		}else {
			System.out.println("Customer not deleted successfully");
		}
		reportStep("Custome deleted   successfully", "pass");
		return this;
	}
	
	
}
