package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class CreateNewVendors extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "CreateNewVendors";
		testDescription ="Verify The New vendor has created";
		authors="Hari";
		category ="Smoke";
		excelFileName="NewVendors";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String vendorId,String vendorName,String vendorDescription
			,String  vendorAddress,String  vendorMobile,String  vendorEmailId,String id,String verifyId) {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickVendorsTap()
		.clickCreateNewVendors()
		.enterVendorId(vendorId)
        .enterVendorName(vendorName)
        .enterVendorDescription(vendorDescription)
        .enterVendorAddress(vendorAddress)
        .enterVendorMobile(vendorMobile)
        .enterVendorEmailId(vendorEmailId)
        .clickSubmitButton()
        .clickVendorsTap()
        .enterId(id)
        .verifyCustomer(verifyId);
	}

}
