package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class DeleteCustomer extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "DeleteCutomer";
		testDescription ="Customer deleted successfully";
		authors="Hari";
		category ="Smoke";
		excelFileName="DeleteCustomer";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String enterId,String deletePopup,String verifyDeletePopup,String deleteId)
			 {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickCustomerTap()
		.enterId(enterId)
		.clickDeleteIcon()
		.confirmDeletePopup(deletePopup)
		.clickOKButton()
		.verifyDeletePopUp(verifyDeletePopup)
		.enterDeleteId(deleteId)
		.verifyCutomerDeleted();
	}

}
