package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class DeleteVendor extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "DeleteProduct";
		testDescription ="Product deleted successfully";
		authors="Hari";
		category ="Smoke";
		excelFileName="DeleteProduct";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String enterId,String deletePopup,
			String verifyDeletePopup,String deleteId)
			 {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickProductTap()
		.enterId(enterId)
		.clickProductDeleteIcon()
		.confirmDeleteProductPopup(deletePopup)
		.clickOKButton()
		.verifyDeletePopUp(verifyDeletePopup)
		.enterDeleteProductId(deleteId)
		.verifyProductDeleted();
	}

}
