package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class CreateNewCutomer extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "CreateNewCutomer";
		testDescription ="Verify The New customer has created";
		authors="Hari";
		category ="Smoke";
		excelFileName="NewCustomer";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String customerId,String customerName,String customerDescription
			,String customeAddress,String customeMobile,String emailId,String id,String verifyId) {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickCustomerTap()
		.clickCreateNewButton()
		.enterCustomerId(customerId)
        .enterCustomerName(customerName)
        .enterCustomerDescription(customerDescription)
        .enterCustomerAddress(customeAddress)
        .enterCustomerMobile(customeMobile)
        .enterEmailId(emailId)
        .clickSubmitButton()
        .clickCustomerTap()
        .enterId(id)
        .verifyCustomer(verifyId);
	}

}
