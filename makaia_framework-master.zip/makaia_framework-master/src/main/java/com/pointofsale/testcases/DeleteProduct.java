package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class DeleteProduct extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "DeleteVendor";
		testDescription ="Vendor deleted successfully";
		authors="Hari";
		category ="Smoke";
		excelFileName="DeleteVendor";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String enterId,String deletePopup,String verifyDeletePopup,String deleteId)
			 {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickVendorsTap()
		.enterId(enterId)
		.clickVendorDeleteIcon()
		.confirmDeleteVendorPopup(deletePopup)
		.clickOKButton()
		.verifyDeletePopUp(verifyDeletePopup)
		.enterDeleteVendorId(deleteId)
		.verifyCutomerDeleted();
	}

}
