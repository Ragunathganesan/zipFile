package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class EditCustomer extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "EditCutomer";
		testDescription ="Verify The New customer name has updated";
		authors="Hari";
		category ="Smoke";
		excelFileName="EditCustomer";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String enterId,String customerName,String verifyEditPopup
			,String verifyId,String customerNameChanged) {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickCustomerTap()
		.enterId(enterId)
		.clickEditIcon()
		.changeCustomerName(customerName)
		.clickSubmitButton()
		.verifyEditedPopup(verifyEditPopup)
		.clickOKButton()
		.enterId(verifyId)
		.verifyCustomerNameChanged(customerNameChanged);
		
	}

}
