package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class EditProduct extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "EditProduct";
		testDescription ="Verify The New Product name has updated";
		authors="Hari";
		category ="Smoke";
		excelFileName="EditProduct";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String productId,String changeProductName,String verifyPopup
			,String verifyId,String productNameChanged) {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickProductTap()
		.enterId(productId)
		.clickProductEditIcon()
		.changeProductName(changeProductName)
		.clickSubmitButton()
		.verifyEditedProductPopup(verifyPopup)
		.clickOKButton()
		.enterId(verifyId)
		.verifyProductNameChanged(productNameChanged);
		
	}

}
