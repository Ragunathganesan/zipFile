package com.pointofsale.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.pointofsale.pages.LoginPage;

public class EditVendors extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "EditVendors";
		testDescription ="Verify The New vendor name has updated";
		authors="Hari";
		category ="Smoke";
		excelFileName="EditVendor";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String userName, String password,
			String enterId,String changeVendorName,String verifyPopup
			,String verifyId,String vendorNameChanged) {
		new LoginPage()
		.enterUserName(userName)
		.enterPassword(password)
		.clickLoginButton()
		.clickVendorsTap()
		.enterId(enterId)
		.clickVendorEditIcon()
		.changeVendorName(changeVendorName) 
		.clickSubmitButton()
		.verifyEditedVendorPopup(verifyPopup)
		.clickOKButton()
		.enterId(verifyId)
		.verifyVendorNameChanged(vendorNameChanged);
		
	}

}
