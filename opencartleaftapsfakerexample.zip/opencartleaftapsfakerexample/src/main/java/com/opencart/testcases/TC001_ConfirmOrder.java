package com.opencart.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.BaseMethods;

import com.opencart.pages.LoginPage;


public class TC001_ConfirmOrder extends BaseMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "Order";
		testDescription ="Verify the order is Confirmed";
		authors="Subraja";
		category ="Smoke";
		excelFileName="Leaftaps";
	}
	
	@Test(dataProvider = "fetchData")
	public void runCart(String uName,String pName) throws InterruptedException {
		new LoginPage().
		enterUsername(uName).enterPassword(pName).clickLoginButton()
		.clickCrmSfalink().clickLeadsButton()
		.clickCreateLeadButton().enterCompanyName()
		.enterFirstName().enterLastName().clickCreateLead();
		
	}

}
