package com.opencart.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class LoginPage extends BaseMethods{

	public LoginPage enterUsername(String uName) {
		typeAndTab(locateElement(Locators.ID, "username"),uName);
		return this;
	}

	public LoginPage enterPassword(String pWord) {
		typeAndTab(locateElement(Locators.ID,"password"),pWord);
		return this;
	}

	public WelcomePage clickLoginButton() {
		//click(locateElement(Locators.CLASS_NAME, "decorativeSubmit"));
//		WebElement ele = locateElement(Locators.CLASS_NAME,"decorativeSubmit");
//        String attribute = ele.getAttribute("value");
//        getAttribute(ele, attribute);
		 String attribute = getAttribute(locateElement(Locators.CLASS_NAME, "decorativeSubmit"),"value");
		 System.out.println(attribute);
	        
        click(locateElement(Locators.CLASS_NAME, "decorativeSubmit"));
       
        
		return new WelcomePage();
	}

}
