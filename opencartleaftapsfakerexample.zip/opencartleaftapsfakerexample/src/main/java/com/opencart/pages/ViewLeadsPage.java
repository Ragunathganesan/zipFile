package com.opencart.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class ViewLeadsPage extends BaseMethods{
	
	public ViewLeadsPage verifyMessage() {
		verifyPartialText(locateElement(Locators.ID, "viewLead_companyName_sp"),"Testleaf");
		return this;

	}

}
