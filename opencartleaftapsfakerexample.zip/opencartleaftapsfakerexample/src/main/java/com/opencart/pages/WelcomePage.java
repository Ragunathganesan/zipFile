package com.opencart.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class WelcomePage extends BaseMethods{
	
	public LeadsPage clickCrmSfalink() {
		click(locateElement(Locators.PARTIAL_LINKTEXT, "CRM/SFA"));
		return new LeadsPage();
	}

}
