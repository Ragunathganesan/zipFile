package com.opencart.pages;

import com.framework.config.ConfigurationManager;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class CreateLeadPage extends BaseMethods{
	
	public CreateLeadFormPage clickCreateLeadButton() throws InterruptedException {
		
		System.out.println( ConfigurationManager.configuration().getCreateLeadLinkText());
 		click(locateElement(Locators.PARTIAL_LINKTEXT, (ConfigurationManager.configuration().getCreateLeadLinkText())));
		return new CreateLeadFormPage();

	}

}
