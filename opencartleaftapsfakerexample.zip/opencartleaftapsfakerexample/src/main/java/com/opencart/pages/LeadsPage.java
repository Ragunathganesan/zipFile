package com.opencart.pages;

import com.framework.config.ConfigurationManager;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class LeadsPage extends BaseMethods{
    public CreateLeadPage clickLeadsButton() {
		
     click(locateElement(Locators.LINK_TEXT, ConfigurationManager.configuration().getLeadLinkText()));
     return new CreateLeadPage();
	}
}
