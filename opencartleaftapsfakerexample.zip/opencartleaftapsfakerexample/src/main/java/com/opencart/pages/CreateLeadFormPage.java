package com.opencart.pages;

import com.framework.data.dynamic.FakerDataFactory;
import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.BaseMethods;

public class CreateLeadFormPage extends BaseMethods{
	
    public CreateLeadFormPage enterCompanyName() {
    	String companyName = FakerDataFactory.getCompanyName();
		clearAndType(locateElement(Locators.ID, "createLeadForm_companyName"),companyName);
		return this;
	}
    
    public CreateLeadFormPage enterFirstName() {
    	String firstName = FakerDataFactory.getFirstName();
		clearAndType(locateElement(Locators.ID, "createLeadForm_firstName"), firstName);
		return this;

	}
    
    public CreateLeadFormPage enterLastName() {
    	String lastName = FakerDataFactory.getLastName();
		clearAndType(locateElement(Locators.ID, "createLeadForm_lastName"), lastName);
		return this;

	}
    
    public ViewLeadsPage clickCreateLead() {
		click(locateElement(Locators.NAME, "submitButton"));
		return new ViewLeadsPage();

	}
    
}
