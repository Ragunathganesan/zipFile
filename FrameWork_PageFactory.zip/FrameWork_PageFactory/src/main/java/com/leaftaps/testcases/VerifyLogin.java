package com.leaftaps.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.BaseMethods;
import com.leaftaps.pages.LoginPage;


public class VerifyLogin extends BaseMethods{
	
	@BeforeTest
	public void setValues() {
		sheetName="Sheet1";
		testcaseName="LoginTest";
		testDescription="Login with vaild credentials";
		authors="Hari";
		category="Smoke";
	
	}
	
	@Test(dataProvider="fetchData")
	public void runLogin(String username,String password) throws InterruptedException {
		
		new LoginPage()
		.enterUserName(username).
		enterPassWord(password).
		clickLoginButton().
		verifyHomePage()
		;
		
	
	}
	
	

}
