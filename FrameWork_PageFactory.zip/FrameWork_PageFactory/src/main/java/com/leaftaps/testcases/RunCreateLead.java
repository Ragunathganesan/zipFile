package com.leaftaps.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.BaseMethods;
import com.leaftaps.pages.LoginPage;


public class RunCreateLead extends BaseMethods{
	@BeforeTest
	public void setValues() {
		sheetName="Sheet2";
		testcaseName="CreateLead";
		testDescription="Create Lead with multiple data";
		authors="Hari";
		category="Sanity";
	
	}
	
	
	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pWord,String cName,String fName,String lName) throws InterruptedException {
		new LoginPage()
		.enterUserName(uName)
		.enterPassWord(pWord)
		.clickLoginButton()
		.verifyHomePage()
		.clickCrmsfalink()
		.clickLeadsButton()
		.clickCreateLeadLink()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickCreateLeadButton()
		.verifyLeads();

	}

}
