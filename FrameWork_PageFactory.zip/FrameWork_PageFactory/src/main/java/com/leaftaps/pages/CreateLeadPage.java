package com.leaftaps.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.framework.testng.api.base.PageObjects;


public class CreateLeadPage extends PageObjects {

	public CreateLeadPage() {
		PageFactory.initElements(getDriver(), this);
	}
	

	public CreateLeadPage enterCompanyName(String companyName) {
		createLeadData.get(0).sendKeys(companyName);
		return this;
	}

	public CreateLeadPage enterFirstName(String firstName) {
		createLeadData.get(2).sendKeys(firstName);
		return this;
	}

	public CreateLeadPage enterLastName(String lastName) {
		createLeadData.get(3).sendKeys(lastName);
		return this;
	}
    
	@FindBy(name = "submitButton") WebElement createLeadButton;
	public ViewLeadsPage clickCreateLeadButton() {
		createLeadButton.click();
		return new ViewLeadsPage();
	}
}
