package com.leaftaps.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.framework.testng.api.base.PageObjects;



public class MyHomePage extends PageObjects{
	
	public MyHomePage() {
		PageFactory.initElements(getDriver(), this);
	}
    
	@FindBy(linkText = "Leads") WebElement leadsLink;
	
	public MyLeadsPage clickLeadsButton() {
		leadsLink.click();
		return new MyLeadsPage();
	}
}
