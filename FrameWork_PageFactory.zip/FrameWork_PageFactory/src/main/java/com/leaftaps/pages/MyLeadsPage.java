package com.leaftaps.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.framework.testng.api.base.PageObjects;



public class MyLeadsPage extends PageObjects{
	
	public MyLeadsPage() {
		PageFactory.initElements(getDriver(), this);
	}

	@FindBy(linkText = "Create Lead") WebElement createLeadLink;
	
    public CreateLeadPage clickCreateLeadLink() {
    	createLeadLink.click();
    	return new CreateLeadPage();
	}
}
