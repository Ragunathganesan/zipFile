package com.leaftaps.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.framework.testng.api.base.PageObjects;


public class LoginPage extends PageObjects {
 
	public LoginPage() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(id="username") WebElement usernameInput;
	@FindBy(id="password") WebElement passwordInput;
	
	
	public LoginPage enterUserName(String username) {
		//usernameInput.sendKeys(username);
		clearAndType(usernameInput, username);
        return this;
	}
	
	public LoginPage enterPassWord(String password) {
		passwordInput.sendKeys(password);
		return this;

	}

	public WelComePage clickLoginButton() {
		clickLogin.click();
		return new WelComePage();
	}


}
