package com.leaftaps.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.framework.testng.api.base.PageObjects;


public class WelComePage extends PageObjects {	
      
	public WelComePage() {
		PageFactory.initElements(getDriver(), this);
	}

	@FindBy(linkText = "CRM/SFA") WebElement crmsfaLink;
	
	public WelComePage verifyHomePage() {
		boolean displayed = crmsfaLink.isDisplayed();
		if (displayed) {
			System.out.println("Login successful");
		}
		else {
			System.out.println("Login unsuccessfull");
		}
		
		return this;
	}
	
	public WelComePage clickLogout() {
		crmsfaLink.click();
		return this;

	}

	public MyHomePage clickCrmsfalink() {
		crmsfaLink.click();
		return new MyHomePage();
	}
}
