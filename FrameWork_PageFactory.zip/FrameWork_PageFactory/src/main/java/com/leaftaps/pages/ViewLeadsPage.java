package com.leaftaps.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.framework.testng.api.base.PageObjects;


public class ViewLeadsPage extends PageObjects{
	
	
	public ViewLeadsPage() {
		PageFactory.initElements(getDriver(), this);
	}
	
	@FindBy(id="viewLead_firstName_sp")WebElement verifyLeadsele;
   public ViewLeadsPage verifyLeads() {
	   String text =verifyLeadsele.getText();
		if (text.equalsIgnoreCase("Subraja")) {
			System.out.println("Lead created successfully");
		} else {
			System.out.println("Lead is not created");
		}
	   
	 
		return this;
}
}
