package com.framework.testng.api.base;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class PageObjects extends BaseMethods{

	
	@FindBy(className = "decorativeSubmit")
	public WebElement clickLogin;
	
	@CacheLookup
	@FindBy(className = "inputBox")
	public List<WebElement> createLeadData;
	
	
	
	
	

}
